"""
test_connection.py
-------------------
Standalone diagnostic: confirms .env loads correctly and a basic
Snowflake connection + query works, independent of the simulator/ETL
code. Run this first whenever you hit a connection error.

Usage:
    python test_connection.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import get_snowflake_config  # noqa: E402
import snowflake.connector  # noqa: E402

print("Loading config from .env...")
cfg = get_snowflake_config()
print(f"  account   = {cfg.account}")
print(f"  user      = {cfg.user}")
print(f"  role      = {cfg.role}")
print(f"  warehouse = {cfg.warehouse}")
print(f"  database  = {cfg.database}")

print("\nConnecting to Snowflake...")
conn = snowflake.connector.connect(
    account=cfg.account,
    user=cfg.user,
    password=cfg.password,
    role=cfg.role,
    warehouse=cfg.warehouse,
    database=cfg.database,
)
print("Connected successfully.")

print("\nRunning test query...")
cur = conn.cursor()
cur.execute("SELECT CURRENT_VERSION(), CURRENT_WAREHOUSE(), CURRENT_DATABASE(), CURRENT_ROLE()")
row = cur.fetchone()
print(f"  Snowflake version : {row[0]}")
print(f"  Warehouse in use  : {row[1]}")
print(f"  Database in use   : {row[2]}")
print(f"  Role in use       : {row[3]}")

print("\nChecking tables exist...")
cur.execute("SHOW TABLES IN DATABASE SMART_CITY_AQI")
tables = cur.fetchall()
print(f"  Found {len(tables)} table(s):")
for t in tables:
    print(f"    - {t[1]}")

conn.close()
print("\nAll checks passed. Connection closed cleanly.")