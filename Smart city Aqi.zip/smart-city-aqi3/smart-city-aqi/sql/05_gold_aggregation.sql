-- 05_gold_aggregation.sql
-- Populates ANALYTICS.CITY_DAILY from CLEAN.AQI_CLEAN.
--
-- Idempotent: deletes today's rows first so this can be safely re-run
-- (e.g. from a scheduled task) without creating duplicate daily rows.
--
-- dominant_risk is computed with a per-city-per-day mode over health_risk
-- using QUALIFY + ROW_NUMBER, since Snowflake has no built-in MODE()
-- aggregate that ties cleanly into a single INSERT...SELECT.

USE DATABASE SMART_CITY_AQI;

DELETE FROM ANALYTICS.CITY_DAILY
WHERE report_date = CURRENT_DATE();

INSERT INTO ANALYTICS.CITY_DAILY (
    city, report_date, avg_aqi, max_aqi, min_aqi, avg_pm25, avg_co2,
    dominant_risk, reading_count
)
WITH daily_stats AS (
    SELECT
        city,
        CAST(recorded_at AS DATE)  AS report_date,
        AVG(aqi_value)             AS avg_aqi,
        MAX(aqi_value)             AS max_aqi,
        MIN(aqi_value)             AS min_aqi,
        AVG(pm25)                  AS avg_pm25,
        AVG(co2_ppm)               AS avg_co2,
        COUNT(*)                   AS reading_count
    FROM CLEAN.AQI_CLEAN
    WHERE CAST(recorded_at AS DATE) = CURRENT_DATE()
    GROUP BY city, CAST(recorded_at AS DATE)
),
risk_counts AS (
    SELECT
        city,
        CAST(recorded_at AS DATE) AS report_date,
        health_risk,
        COUNT(*) AS risk_count
    FROM CLEAN.AQI_CLEAN
    WHERE CAST(recorded_at AS DATE) = CURRENT_DATE()
    GROUP BY city, CAST(recorded_at AS DATE), health_risk
),
dominant AS (
    SELECT city, report_date, health_risk AS dominant_risk
    FROM risk_counts
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY city, report_date
        ORDER BY risk_count DESC
    ) = 1
)
SELECT
    d.city,
    d.report_date,
    d.avg_aqi,
    d.max_aqi,
    d.min_aqi,
    d.avg_pm25,
    d.avg_co2,
    r.dominant_risk,
    d.reading_count
FROM daily_stats d
JOIN dominant r
  ON d.city = r.city AND d.report_date = r.report_date;

-- Tip: wrap this file in a Snowflake TASK on a schedule (e.g. every 15 min)
-- to keep the Gold layer near-real-time:
--
-- CREATE OR REPLACE TASK ANALYTICS.REFRESH_CITY_DAILY
--   WAREHOUSE = <your_warehouse>
--   SCHEDULE = '15 MINUTE'
-- AS
--   <paste this DELETE + INSERT as the task body>;
-- ALTER TASK ANALYTICS.REFRESH_CITY_DAILY RESUME;
