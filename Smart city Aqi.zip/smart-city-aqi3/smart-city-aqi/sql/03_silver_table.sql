-- 03_silver_table.sql
-- Silver layer: validated + enriched, unions both sources into one shape.

USE DATABASE SMART_CITY_AQI;
USE SCHEMA CLEAN;

CREATE TABLE IF NOT EXISTS CLEAN.AQI_CLEAN (
    clean_id        NUMBER AUTOINCREMENT PRIMARY KEY,
    source          VARCHAR(20)     NOT NULL,   -- 'iot_simulator' OR 'openaq_v3'
    city            VARCHAR(100),
    sensor_id       VARCHAR(30),                -- NULL for OpenAQ rows
    pm25            FLOAT,
    pm10            FLOAT,
    co2_ppm         FLOAT,
    aqi_value       FLOAT,
    aqi_category    VARCHAR(40),                -- Good / Moderate / Unhealthy etc.
    health_risk     VARCHAR(10),                -- LOW / MEDIUM / HIGH / CRITICAL
    latitude        FLOAT,
    longitude       FLOAT,
    recorded_at     TIMESTAMP_NTZ,
    processed_at    TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
