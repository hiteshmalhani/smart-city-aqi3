-- 01_setup_database.sql
-- Creates the database and the three medallion-architecture schemas.
-- Run this first, in a Snowflake worksheet, before loading any data.

CREATE DATABASE IF NOT EXISTS SMART_CITY_AQI;

CREATE SCHEMA IF NOT EXISTS SMART_CITY_AQI.RAW;        -- Bronze
CREATE SCHEMA IF NOT EXISTS SMART_CITY_AQI.CLEAN;      -- Silver
CREATE SCHEMA IF NOT EXISTS SMART_CITY_AQI.ANALYTICS;  -- Gold

-- Optional: dedicated warehouse sized for hackathon workloads.
-- CREATE WAREHOUSE IF NOT EXISTS SMART_CITY_AQI_WH
--   WAREHOUSE_SIZE = 'XSMALL'
--   AUTO_SUSPEND = 60
--   AUTO_RESUME = TRUE;
