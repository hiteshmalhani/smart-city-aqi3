-- 04_gold_table.sql
-- Gold layer: one row per city per day, powering the dashboard KPIs.

USE DATABASE SMART_CITY_AQI;
USE SCHEMA ANALYTICS;

CREATE TABLE IF NOT EXISTS ANALYTICS.CITY_DAILY (
    daily_id        NUMBER AUTOINCREMENT PRIMARY KEY,
    city            VARCHAR(100),
    report_date     DATE,
    avg_aqi         FLOAT,
    max_aqi         FLOAT,
    min_aqi         FLOAT,
    avg_pm25        FLOAT,
    avg_co2         FLOAT,
    dominant_risk   VARCHAR(10),   -- most common health_risk of the day
    reading_count   NUMBER,        -- total rows from both sources
    created_at      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
