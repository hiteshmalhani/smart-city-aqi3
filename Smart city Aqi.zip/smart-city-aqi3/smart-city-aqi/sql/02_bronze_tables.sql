-- 02_bronze_tables.sql
-- Bronze layer: raw data as-is from each source, no cleaning applied.

USE DATABASE SMART_CITY_AQI;
USE SCHEMA RAW;

CREATE TABLE IF NOT EXISTS RAW.IOT_READINGS (
    reading_id      NUMBER AUTOINCREMENT PRIMARY KEY,
    sensor_id       VARCHAR(30)     NOT NULL,
    city            VARCHAR(100),
    zone_type       VARCHAR(30),
    pm25            FLOAT,
    pm10            FLOAT,
    co2_ppm         FLOAT,
    temperature_c   FLOAT,
    humidity_pct    FLOAT,
    wind_speed_kmh  FLOAT,
    aqi_value       FLOAT,
    severity        VARCHAR(30),
    recorded_at     TIMESTAMP_NTZ,
    ingested_at     TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE TABLE IF NOT EXISTS RAW.OPENAQ_RAW (
    raw_id          NUMBER AUTOINCREMENT PRIMARY KEY,
    location_id     INTEGER,
    station_name    VARCHAR(200),
    city            VARCHAR(100),
    country_code    VARCHAR(5),
    latitude        FLOAT,
    longitude       FLOAT,
    pollutant_type  VARCHAR(20),
    pollutant_value FLOAT,
    unit            VARCHAR(20),
    recorded_at     TIMESTAMP_NTZ,
    ingested_at     TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
