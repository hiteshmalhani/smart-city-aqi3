"""
common/aqi.py
-------------
Single source of truth for the EPA AQI formula and derived category
labels, so the simulator and the ETL pipeline can never drift out of
sync with each other.
"""

from config import AQI_BREAKPOINTS


def calculate_aqi(pm25: float) -> float:
    """Converts a PM2.5 concentration (µg/m3) into an AQI value using the
    standard EPA piecewise-linear formula:

        AQI = ((I_hi - I_lo) / (C_hi - C_lo)) * (PM2.5 - C_lo) + I_lo

    Values above the top breakpoint are clamped to the HAZARDOUS band's
    upper bound (500) rather than raising, since real/simulated sensors
    can occasionally spike past the official table.
    """
    if pm25 < 0:
        pm25 = 0.0

    for c_lo, c_hi, i_lo, i_hi, _label in AQI_BREAKPOINTS:
        if c_lo <= pm25 <= c_hi:
            aqi = ((i_hi - i_lo) / (c_hi - c_lo)) * (pm25 - c_lo) + i_lo
            return round(aqi, 1)

    # Above the highest breakpoint -> clamp to max AQI.
    if pm25 > AQI_BREAKPOINTS[-1][1]:
        return 500.0

    # Should not happen, but fail safe rather than raise mid-stream.
    return 0.0


def aqi_category(pm25: float) -> str:
    """Returns the EPA severity label (GOOD / MODERATE / ... / HAZARDOUS)
    for a given PM2.5 value, using the same breakpoint table as
    calculate_aqi so the two never disagree.
    """
    if pm25 < 0:
        pm25 = 0.0

    for c_lo, c_hi, _i_lo, _i_hi, label in AQI_BREAKPOINTS:
        if c_lo <= pm25 <= c_hi:
            return label

    return "HAZARDOUS" if pm25 > AQI_BREAKPOINTS[-1][1] else "GOOD"


def health_risk_from_category(category: str) -> str:
    """Maps the 6-level EPA category down to the 4-level health_risk
    bucket required by the Silver layer schema.
    """
    mapping = {
        "GOOD": "LOW",
        "MODERATE": "LOW",
        "UNHEALTHY_FOR_SENSITIVE": "MEDIUM",
        "UNHEALTHY": "HIGH",
        "VERY_UNHEALTHY": "HIGH",
        "HAZARDOUS": "CRITICAL",
    }
    return mapping.get(category, "LOW")
