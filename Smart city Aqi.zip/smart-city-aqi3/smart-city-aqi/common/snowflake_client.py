"""
common/snowflake_client.py
---------------------------
Thin wrapper around snowflake-connector-python so every script
(simulator, ETL, dashboard) opens connections the same way and doesn't
leak credentials into logs.
"""

import logging
from contextlib import contextmanager

import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas

from config import get_snowflake_config

logger = logging.getLogger(__name__)


@contextmanager
def get_connection():
    """Context manager yielding a live Snowflake connection.

    Usage:
        with get_connection() as conn:
            conn.cursor().execute("SELECT 1")
    """
    cfg = get_snowflake_config()
    conn = snowflake.connector.connect(
        account=cfg.account,
        user=cfg.user,
        password=cfg.password,
        role=cfg.role,
        warehouse=cfg.warehouse,
        database=cfg.database,
    )
    logger.info("Connected to Snowflake account=%s database=%s", cfg.account, cfg.database)
    try:
        yield conn
    finally:
        conn.close()


def insert_dataframe(conn, df, table: str, schema: str, database: str = None):
    """Bulk-loads a pandas DataFrame into a Snowflake table using the
    connector's native (COPY-based) bulk writer — far faster than
    row-by-row INSERTs for hundreds/thousands of readings.

    `table` must already exist with matching column names (see sql/ for
    DDL). Column names in the DataFrame are upper-cased to match
    Snowflake's default unquoted identifier behavior.
    """
    if df.empty:
        logger.info("insert_dataframe: nothing to load into %s.%s (empty DataFrame)", schema, table)
        return 0

    df = df.copy()
    df.columns = [c.upper() for c in df.columns]

    success, n_chunks, n_rows, _ = write_pandas(
        conn,
        df,
        table_name=table.upper(),
        schema=schema.upper(),
        database=database,
        quote_identifiers=False,
    )
    if not success:
        raise RuntimeError(f"write_pandas reported failure loading {schema}.{table}")

    logger.info("Loaded %d rows into %s.%s (%d chunk(s))", n_rows, schema, table, n_chunks)
    return n_rows
