"""
simulator/iot_simulator.py
---------------------------
Simulates 10 IoT air-quality sensors across 5 Pakistani cities, one
reading per sensor every 10 seconds, and streams the data to a local
CSV file plus the Snowflake RAW.IOT_READINGS bronze table.

Run:
    python simulator/iot_simulator.py                 # run indefinitely
    python simulator/iot_simulator.py --minutes 30     # run for 30 min
    python simulator/iot_simulator.py --no-snowflake   # CSV only (offline dev)
"""

import argparse
import csv
import logging
import math
import os
import random
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from common.aqi import aqi_category, calculate_aqi  # noqa: E402
from common.snowflake_client import get_connection, insert_dataframe  # noqa: E402
from config import SENSOR_NETWORK, ZONE_BASE_RANGES  # noqa: E402

import pandas as pd  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("iot_simulator")

CSV_PATH = Path(__file__).resolve().parent.parent / "data" / "iot_readings.csv"
CSV_FIELDS = [
    "sensor_id", "city", "zone_type", "pm25", "pm10", "co2_ppm",
    "temperature_c", "humidity_pct", "wind_speed_kmh", "aqi_value",
    "severity", "recorded_at",
]

ANOMALY_PROBABILITY = 0.15
ANOMALY_MULTIPLIER_RANGE = (2.5, 4.0)
NOISE_PCT = 0.15
BATCH_INTERVAL_SECONDS = 10


def time_of_day_multiplier(hour: int) -> float:
    """Peaks at 8am and 6pm per spec: 1.0 + 0.3 * sin((hour - 8) * pi / 12)."""
    return 1.0 + 0.3 * math.sin((hour - 8) * math.pi / 12)


def generate_reading(sensor: dict, now: datetime) -> dict:
    """Generates a single realistic reading for one sensor at timestamp `now`."""
    zone = sensor["zone_type"]
    ranges = ZONE_BASE_RANGES[zone]
    tod_mult = time_of_day_multiplier(now.hour)

    def noisy(base_lo, base_hi):
        base = random.uniform(base_lo, base_hi) * tod_mult
        noise = base * random.uniform(-NOISE_PCT, NOISE_PCT)
        return base + noise

    pm25 = max(0.0, noisy(*ranges["pm25"]))

    # 15% chance of an anomaly spike (e.g. a nearby fire, generator, traffic jam).
    if random.random() < ANOMALY_PROBABILITY:
        pm25 *= random.uniform(*ANOMALY_MULTIPLIER_RANGE)
    pm25 = round(min(pm25, 500.0), 2)

    # pm10 is always >= pm25 (coarse particles are a superset of fine ones).
    pm10 = round(min(pm25 + random.uniform(5, 40), 600.0), 2)

    co2_ppm = round(min(max(noisy(*ranges["co2"]), 400), 2000), 1)
    temperature_c = round(min(max(noisy(*ranges["temp"]), 15), 45), 1)
    humidity_pct = round(random.uniform(10, 90), 1)
    wind_speed_kmh = round(random.uniform(0, 60), 1)

    aqi_value = calculate_aqi(pm25)
    severity = aqi_category(pm25)

    return {
        "sensor_id": sensor["sensor_id"],
        "city": sensor["city"],
        "zone_type": zone,
        "pm25": pm25,
        "pm10": pm10,
        "co2_ppm": co2_ppm,
        "temperature_c": temperature_c,
        "humidity_pct": humidity_pct,
        "wind_speed_kmh": wind_speed_kmh,
        "aqi_value": aqi_value,
        "severity": severity,
        "recorded_at": now.isoformat(),
    }


def append_to_csv(readings: list[dict]) -> None:
    CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
    write_header = not CSV_PATH.exists()
    with open(CSV_PATH, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if write_header:
            writer.writeheader()
        writer.writerows(readings)


def run(duration_minutes: float | None, use_snowflake: bool) -> None:
    logger.info(
        "Starting IoT simulator: %d sensors, 1 reading/sensor every %ds%s",
        len(SENSOR_NETWORK),
        BATCH_INTERVAL_SECONDS,
        f", running for {duration_minutes} min" if duration_minutes else " (indefinitely, Ctrl+C to stop)",
    )

    conn = None
    if use_snowflake:
        conn = get_connection().__enter__()

    start = time.monotonic()
    batch_count = 0
    try:
        while True:
            now = datetime.now(timezone.utc)
            readings = [generate_reading(sensor, now) for sensor in SENSOR_NETWORK]

            for r in readings:
                if r["severity"] in ("UNHEALTHY", "VERY_UNHEALTHY", "HAZARDOUS"):
                    logger.warning(
                        "%s [%s] pm25=%.1f aqi=%.0f severity=%s",
                        r["sensor_id"], r["city"], r["pm25"], r["aqi_value"], r["severity"],
                    )

            append_to_csv(readings)

            if conn is not None:
                df = pd.DataFrame(readings)
                insert_dataframe(conn, df, table="IOT_READINGS", schema="RAW")

            batch_count += 1
            logger.info("Batch %d complete: %d readings written", batch_count, len(readings))

            if duration_minutes is not None and (time.monotonic() - start) >= duration_minutes * 60:
                logger.info("Duration limit reached (%s min). Stopping.", duration_minutes)
                break

            time.sleep(BATCH_INTERVAL_SECONDS)
    except KeyboardInterrupt:
        logger.info("Interrupted by user. Stopping.")
    finally:
        if conn is not None:
            conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Smart City AQI IoT sensor simulator")
    parser.add_argument("--minutes", type=float, default=None, help="Run for N minutes then stop (default: run forever)")
    parser.add_argument("--no-snowflake", action="store_true", help="Only write CSV, skip Snowflake inserts (offline dev)")
    args = parser.parse_args()

    run(duration_minutes=args.minutes, use_snowflake=not args.no_snowflake)
