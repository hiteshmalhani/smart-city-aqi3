#!/usr/bin/env bash
# Runs the full pipeline end-to-end for a demo:
#   1. Simulator in the background for N minutes
#   2. OpenAQ fetch
#   3. ETL (Bronze -> Silver -> Gold)
#   4. Launch the dashboard
#
# Usage: ./scripts/run_pipeline.sh [minutes]

set -e
MINUTES="${1:-2}"

cd "$(dirname "$0")/.."

echo ">>> Running IoT simulator for ${MINUTES} minute(s) in the background..."
python simulator/iot_simulator.py --minutes "$MINUTES" &
SIM_PID=$!

echo ">>> Fetching OpenAQ reference data..."
python openaq/openaq_fetcher.py

wait $SIM_PID
echo ">>> Simulator finished."

echo ">>> Running ETL pipeline (Bronze -> Silver -> Gold)..."
python etl/etl_pipeline.py

echo ">>> Launching dashboard..."
streamlit run dashboard/app.py
