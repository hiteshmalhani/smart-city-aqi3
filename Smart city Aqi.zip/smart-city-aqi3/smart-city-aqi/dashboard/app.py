"""
dashboard/app.py
------------------
Stage 4 — Streamlit dashboard for decision-makers.

Queries Snowflake's Gold (ANALYTICS.CITY_DAILY) and Silver
(CLEAN.AQI_CLEAN) layers directly and auto-refreshes every 30 seconds.

Run:
    streamlit run dashboard/app.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd  # noqa: E402
import plotly.express as px  # noqa: E402
import snowflake.connector  # noqa: E402
import streamlit as st  # noqa: E402

from config import get_snowflake_config  # noqa: E402

st.set_page_config(page_title="Smart City AQI — Pakistan", layout="wide", page_icon="🌫️")

SEVERITY_COLORS = {
    "GOOD": "#2ecc71",
    "MODERATE": "#f1c40f",
    "UNHEALTHY_FOR_SENSITIVE": "#e67e22",
    "UNHEALTHY": "#e74c3c",
    "VERY_UNHEALTHY": "#8e44ad",
    "HAZARDOUS": "#6c1b1b",
}
RISK_BADGE = {"LOW": "🟢 LOW", "MEDIUM": "🟡 MEDIUM", "HIGH": "🔴 HIGH", "CRITICAL": "🟣 CRITICAL"}


@st.cache_resource
def get_conn():
    cfg = get_snowflake_config()
    return snowflake.connector.connect(
        account=cfg.account, user=cfg.user, password=cfg.password,
        role=cfg.role, warehouse=cfg.warehouse, database=cfg.database,
    )


@st.cache_data(ttl=30)
def load_city_daily() -> pd.DataFrame:
    conn = get_conn()
    return pd.read_sql(
        """
        SELECT CITY, REPORT_DATE, AVG_AQI, MAX_AQI, MIN_AQI, AVG_PM25, AVG_CO2,
               DOMINANT_RISK, READING_COUNT
        FROM ANALYTICS.CITY_DAILY
        ORDER BY REPORT_DATE DESC
        """,
        conn,
    )


@st.cache_data(ttl=30)
def load_recent_readings(hours: int = 6) -> pd.DataFrame:
    conn = get_conn()
    return pd.read_sql(
        f"""
        SELECT SOURCE, CITY, SENSOR_ID, PM25, AQI_VALUE, AQI_CATEGORY,
               HEALTH_RISK, RECORDED_AT
        FROM CLEAN.AQI_CLEAN
        WHERE RECORDED_AT >= DATEADD(hour, -{hours}, CURRENT_TIMESTAMP())
        ORDER BY RECORDED_AT DESC
        """,
        conn,
    )


st.title("🌫️ Smart City Air Quality Monitoring — Pakistan")
st.caption("IoT sensor network + OpenAQ V3 reference data · auto-refreshes every 30s")

try:
    city_daily = load_city_daily()
    recent = load_recent_readings()
except Exception as e:
    st.error(f"Could not query Snowflake: {e}")
    st.info("Check your .env credentials and confirm the ETL pipeline has loaded data into CLEAN.AQI_CLEAN / ANALYTICS.CITY_DAILY.")
    st.stop()

today = city_daily[city_daily["REPORT_DATE"] == city_daily["REPORT_DATE"].max()] if not city_daily.empty else city_daily

# --------------------------------------------------------------------------
# Metric cards
# --------------------------------------------------------------------------
col1, col2, col3 = st.columns(3)

if not today.empty:
    top_city_row = today.loc[today["AVG_AQI"].idxmax()]
    col1.metric("Highest AQI City", top_city_row["CITY"], f"{top_city_row['AVG_AQI']:.0f} AQI")
else:
    col1.metric("Highest AQI City", "—")

total_readings = int(recent.shape[0])
col2.metric("Readings (last 6h)", f"{total_readings:,}")

if total_readings > 0:
    pct_critical = (recent["HEALTH_RISK"] == "CRITICAL").mean() * 100
    col3.metric("% CRITICAL Readings", f"{pct_critical:.1f}%")
else:
    col3.metric("% CRITICAL Readings", "0.0%")

st.divider()

# --------------------------------------------------------------------------
# Bar chart — average AQI per city today
# --------------------------------------------------------------------------
st.subheader("Average AQI per City — Today")
if not today.empty:
    fig_bar = px.bar(
        today.sort_values("AVG_AQI", ascending=False),
        x="CITY", y="AVG_AQI", color="AVG_AQI",
        color_continuous_scale=["#2ecc71", "#f1c40f", "#e74c3c", "#6c1b1b"],
        labels={"AVG_AQI": "Average AQI", "CITY": "City"},
    )
    st.plotly_chart(fig_bar, use_container_width=True)
else:
    st.info("No Gold-layer data yet for today. Run the ETL pipeline first.")

# --------------------------------------------------------------------------
# Line chart — AQI trend per sensor, last 6 hours
# --------------------------------------------------------------------------
st.subheader("AQI Trend — Last 6 Hours")
if not recent.empty:
    trend = recent.dropna(subset=["SENSOR_ID"])
    if not trend.empty:
        fig_line = px.line(
            trend.sort_values("RECORDED_AT"),
            x="RECORDED_AT", y="AQI_VALUE", color="SENSOR_ID",
            labels={"RECORDED_AT": "Time", "AQI_VALUE": "AQI"},
        )
        st.plotly_chart(fig_line, use_container_width=True)
    else:
        st.info("No sensor-level readings in the last 6 hours yet.")
else:
    st.info("No recent readings found.")

# --------------------------------------------------------------------------
# Color-coded severity table
# --------------------------------------------------------------------------
st.subheader("Recent Readings — Severity Badges")
if not recent.empty:
    display_df = recent.copy()
    display_df["RISK BADGE"] = display_df["HEALTH_RISK"].map(RISK_BADGE).fillna(display_df["HEALTH_RISK"])
    st.dataframe(
        display_df[["RECORDED_AT", "SOURCE", "CITY", "SENSOR_ID", "PM25", "AQI_VALUE", "AQI_CATEGORY", "RISK BADGE"]]
        .head(200),
        use_container_width=True,
        hide_index=True,
    )
else:
    st.info("No readings to display yet.")
