"""
etl/etl_pipeline.py
--------------------
Stage 2 — Extract, Transform, Load.

Reads the raw IoT CSV and OpenAQ CSV produced by the simulator and
fetcher (or pulls straight from Snowflake RAW tables if --from-snowflake
is passed), cleans + validates both, unions them into the Silver shape,
and loads CLEAN.AQI_CLEAN. Finally triggers the Gold aggregation SQL.

Run:
    python etl/etl_pipeline.py
    python etl/etl_pipeline.py --from-snowflake     # read Bronze from Snowflake instead of local CSVs
    python etl/etl_pipeline.py --no-snowflake-load  # transform only, write clean CSV, skip Silver load
"""

import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd  # noqa: E402

from common.aqi import aqi_category, health_risk_from_category  # noqa: E402
from common.snowflake_client import get_connection, insert_dataframe  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("etl_pipeline")

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
SQL_DIR = Path(__file__).resolve().parent.parent / "sql"


# --------------------------------------------------------------------------
# Extract
# --------------------------------------------------------------------------
def extract_from_csv() -> tuple[pd.DataFrame, pd.DataFrame]:
    iot_path = DATA_DIR / "iot_readings.csv"
    openaq_path = DATA_DIR / "openaq_raw.csv"

    iot_df = pd.read_csv(iot_path) if iot_path.exists() else pd.DataFrame()
    openaq_df = pd.read_csv(openaq_path) if openaq_path.exists() else pd.DataFrame()

    logger.info("Extracted %d IoT rows, %d OpenAQ rows from local CSV", len(iot_df), len(openaq_df))
    return iot_df, openaq_df


def extract_from_snowflake() -> tuple[pd.DataFrame, pd.DataFrame]:
    with get_connection() as conn:
        iot_df = pd.read_sql("SELECT * FROM RAW.IOT_READINGS", conn)
        openaq_df = pd.read_sql("SELECT * FROM RAW.OPENAQ_RAW", conn)
    iot_df.columns = [c.lower() for c in iot_df.columns]
    openaq_df.columns = [c.lower() for c in openaq_df.columns]
    logger.info("Extracted %d IoT rows, %d OpenAQ rows from Snowflake RAW", len(iot_df), len(openaq_df))
    return iot_df, openaq_df


# --------------------------------------------------------------------------
# Transform — IoT
# --------------------------------------------------------------------------
def transform_iot(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    before = len(df)
    df = df.dropna(subset=["pm25", "aqi_value"])

    # Range validation per spec.
    df = df[(df["pm25"] >= 0) & (df["pm25"] <= 500)]
    df = df[(df["co2_ppm"] >= 400) & (df["co2_ppm"] <= 2000)]
    df = df[(df["humidity_pct"] >= 0) & (df["humidity_pct"] <= 100)]

    df["aqi_category"] = df["pm25"].apply(aqi_category)
    df["health_risk"] = df["aqi_category"].apply(health_risk_from_category)

    df = df.drop_duplicates(subset=["sensor_id", "recorded_at"])
    df["processed_at"] = pd.Timestamp.utcnow()
    df["source"] = "iot_simulator"

    logger.info("IoT transform: %d -> %d rows after cleaning/validation", before, len(df))
    return df


# --------------------------------------------------------------------------
# Transform — OpenAQ
# --------------------------------------------------------------------------
def transform_openaq(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    before = len(df)
    df = df[df["pollutant_type"].isin(["pm25", "pm10"])]
    df = df.dropna(subset=["pollutant_value"])
    df = df[df["pollutant_value"] > 0]

    df["recorded_at"] = pd.to_datetime(df["recorded_at"], utc=True, errors="coerce")
    df = df.dropna(subset=["recorded_at"])

    df["source"] = "openaq_v3"
    df["country_code"] = "PK"

    logger.info("OpenAQ transform: %d -> %d rows after cleaning/validation", before, len(df))
    return df


# --------------------------------------------------------------------------
# Reshape both sources into the shared Silver schema and union them
# --------------------------------------------------------------------------
def to_silver_shape(iot_df: pd.DataFrame, openaq_df: pd.DataFrame) -> pd.DataFrame:
    silver_cols = [
        "source", "city", "sensor_id", "pm25", "pm10", "co2_ppm", "aqi_value",
        "aqi_category", "health_risk", "latitude", "longitude", "recorded_at",
    ]

    iot_silver = pd.DataFrame()
    if not iot_df.empty:
        iot_silver = pd.DataFrame({
            "source": iot_df["source"],
            "city": iot_df["city"],
            "sensor_id": iot_df["sensor_id"],
            "pm25": iot_df["pm25"],
            "pm10": iot_df["pm10"],
            "co2_ppm": iot_df["co2_ppm"],
            "aqi_value": iot_df["aqi_value"],
            "aqi_category": iot_df["aqi_category"],
            "health_risk": iot_df["health_risk"],
            "latitude": pd.NA,
            "longitude": pd.NA,
            "recorded_at": iot_df["recorded_at"],
        })

    openaq_silver = pd.DataFrame()
    if not openaq_df.empty:
        # OpenAQ rows are per-pollutant; pivot pm25/pm10 side by side per
        # station+timestamp so each row matches the Silver table's shape
        # (one row with both pm25 and pm10 columns, like the IoT rows).
        pivot = openaq_df.pivot_table(
            index=["station_name", "city", "latitude", "longitude", "recorded_at"],
            columns="pollutant_type",
            values="pollutant_value",
            aggfunc="mean",
        ).reset_index()

        for col in ("pm25", "pm10"):
            if col not in pivot.columns:
                pivot[col] = pd.NA

        pivot["aqi_category"] = pivot["pm25"].apply(lambda v: aqi_category(v) if pd.notna(v) else None)
        pivot["health_risk"] = pivot["aqi_category"].apply(lambda c: health_risk_from_category(c) if c else None)
        pivot["aqi_value"] = pivot["pm25"].apply(lambda v: None if pd.isna(v) else v)  # AQI recomputed downstream from pm25 if needed

        openaq_silver = pd.DataFrame({
            "source": "openaq_v3",
            "city": pivot["city"],
            "sensor_id": pd.NA,  # NULL for OpenAQ rows per spec
            "pm25": pivot["pm25"],
            "pm10": pivot["pm10"],
            "co2_ppm": pd.NA,
            "aqi_value": pivot["aqi_value"],
            "aqi_category": pivot["aqi_category"],
            "health_risk": pivot["health_risk"],
            "latitude": pivot["latitude"],
            "longitude": pivot["longitude"],
            "recorded_at": pivot["recorded_at"],
        })

    combined = pd.concat([iot_silver, openaq_silver], ignore_index=True)
    combined = combined[silver_cols] if not combined.empty else pd.DataFrame(columns=silver_cols)
    combined["processed_at"] = pd.Timestamp.utcnow()
    return combined


# --------------------------------------------------------------------------
# Load
# --------------------------------------------------------------------------
def load(df: pd.DataFrame, use_snowflake: bool) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    out_path = DATA_DIR / "aqi_clean.csv"
    df.to_csv(out_path, index=False)
    logger.info("Wrote %d clean rows to %s", len(df), out_path)

    if use_snowflake and not df.empty:
        with get_connection() as conn:
            insert_dataframe(conn, df, table="AQI_CLEAN", schema="CLEAN")
            logger.info("Running Gold aggregation SQL...")
            gold_sql = (SQL_DIR / "05_gold_aggregation.sql").read_text()
            # Snowflake connector executes one statement per .execute() call;
            # split on ';' and skip comment-only / blank statements.
            cur = conn.cursor()
            for stmt in gold_sql.split(";"):
                stmt = stmt.strip()
                if not stmt or stmt.startswith("--"):
                    continue
                cur.execute(stmt)
            logger.info("Gold layer (ANALYTICS.CITY_DAILY) refreshed for today.")


def run(from_snowflake: bool, use_snowflake_load: bool) -> None:
    iot_df, openaq_df = extract_from_snowflake() if from_snowflake else extract_from_csv()

    iot_clean = transform_iot(iot_df)
    openaq_clean = transform_openaq(openaq_df)

    silver_df = to_silver_shape(iot_clean, openaq_clean)
    load(silver_df, use_snowflake=use_snowflake_load)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Smart City AQI ETL pipeline (Bronze -> Silver -> Gold)")
    parser.add_argument("--from-snowflake", action="store_true", help="Read Bronze data from Snowflake RAW tables instead of local CSVs")
    parser.add_argument("--no-snowflake-load", action="store_true", help="Write clean CSV only, skip loading Silver/Gold into Snowflake")
    args = parser.parse_args()

    run(from_snowflake=args.from_snowflake, use_snowflake_load=not args.no_snowflake_load)
