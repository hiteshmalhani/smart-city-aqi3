"""
openaq/openaq_fetcher.py
--------------------------
Pulls real reference air-quality data for Pakistan from the OpenAQ V3
API and writes it to a local JSON/CSV snapshot plus the Snowflake
RAW.OPENAQ_RAW bronze table.

Implements the 4-step flow from the spec:
    1. GET /v3/locations              -> Pakistan monitoring stations
    2. GET /v3/locations/{id}/sensors -> sensors + parameters per station
    3. GET /v3/locations/{id}/latest  -> latest reading per sensor
    4. GET /v3/sensors/{id}/measurements -> optional 24h history

Run:
    python openaq/openaq_fetcher.py
    python openaq/openaq_fetcher.py --history        # also pull 24h history
    python openaq/openaq_fetcher.py --no-snowflake   # CSV only
"""

import argparse
import json
import logging
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd  # noqa: E402
import requests  # noqa: E402

from common.snowflake_client import get_connection, insert_dataframe  # noqa: E402
from config import OPENAQ_API_KEY, OPENAQ_BASE_URL, OPENAQ_REQUEST_DELAY_SECONDS  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("openaq_fetcher")

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
RELEVANT_PARAMETERS = {"pm25", "pm10"}


class OpenAQClient:
    """Small wrapper around the OpenAQ V3 REST API."""

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or OPENAQ_API_KEY
        if not self.api_key:
            raise EnvironmentError(
                "OPENAQ_API_KEY is not set. Register at explore.openaq.org/register, "
                "then put OPENAQ_API_KEY=... in your .env file."
            )
        self.session = requests.Session()
        self.session.headers.update({"X-API-Key": self.api_key})

    def _get(self, path: str, params: dict | None = None) -> dict:
        url = f"{OPENAQ_BASE_URL}{path}"
        resp = self.session.get(url, params=params or {}, timeout=30)
        time.sleep(OPENAQ_REQUEST_DELAY_SECONDS)  # stay under 60 req/min

        if resp.status_code == 429:
            logger.warning("Rate limited by OpenAQ, backing off 5s and retrying once...")
            time.sleep(5)
            resp = self.session.get(url, params=params or {}, timeout=30)

        resp.raise_for_status()
        return resp.json()

    def get_pakistan_locations(self, limit: int = 100) -> list[dict]:
        """Step 1: all OpenAQ monitoring stations in Pakistan."""
        data = self._get("/locations", params={"country_id": "PK", "limit": limit})
        results = data.get("results", [])
        logger.info("Found %d OpenAQ locations in Pakistan", len(results))
        return results

    def get_location_sensors(self, location_id: int) -> list[dict]:
        """Step 2: sensor IDs + parameters measured at a location."""
        data = self._get(f"/locations/{location_id}/sensors")
        return data.get("results", [])

    def get_latest_for_location(self, location_id: int) -> list[dict]:
        """Step 3: most recent reading from each sensor at a location."""
        data = self._get(f"/locations/{location_id}/latest")
        return data.get("results", [])

    def get_sensor_measurements(self, sensor_id: int, date_from: str, date_to: str, limit: int = 100) -> list[dict]:
        """Step 4 (optional): historical measurements for trend comparison."""
        data = self._get(
            f"/sensors/{sensor_id}/measurements",
            params={"date_from": date_from, "date_to": date_to, "limit": limit},
        )
        return data.get("results", [])


def build_raw_rows(client: OpenAQClient, locations: list[dict]) -> list[dict]:
    """Joins locations + sensors + latest readings into flat rows matching
    the V3 -> Snowflake field mapping table in the spec.
    """
    rows = []
    for loc in locations:
        location_id = loc.get("id")
        name = loc.get("name")
        locality = loc.get("locality") or loc.get("name")
        country_code = (loc.get("country") or {}).get("code", "PK")
        coords = loc.get("coordinates") or {}
        latitude = coords.get("latitude")
        longitude = coords.get("longitude")

        try:
            sensors = client.get_location_sensors(location_id)
        except requests.HTTPError as e:
            logger.warning("Could not fetch sensors for location %s: %s", location_id, e)
            continue

        try:
            latest_readings = client.get_latest_for_location(location_id)
        except requests.HTTPError as e:
            logger.warning("Could not fetch latest readings for location %s: %s", location_id, e)
            continue

        # Index latest readings by sensor id for quick lookup.
        latest_by_sensor = {r.get("sensorsId") or r.get("sensor_id"): r for r in latest_readings}

        for sensor in sensors:
            param = (sensor.get("parameter") or {})
            pollutant_type = param.get("name")
            if pollutant_type not in RELEVANT_PARAMETERS:
                continue  # ETL filters to pm25/pm10 anyway; skip early to save rows

            sensor_id = sensor.get("id")
            latest = latest_by_sensor.get(sensor_id, {})
            value = latest.get("value")
            recorded = (latest.get("datetime") or {})
            recorded_at = recorded.get("utc") if isinstance(recorded, dict) else recorded

            rows.append({
                "location_id": location_id,
                "station_name": name,
                "city": locality,
                "country_code": country_code,
                "latitude": latitude,
                "longitude": longitude,
                "pollutant_type": pollutant_type,
                "pollutant_value": value,
                "unit": param.get("units"),
                "recorded_at": recorded_at,
            })

    return rows


def fetch_history(client: OpenAQClient, locations: list[dict], hours: int = 24) -> list[dict]:
    """Step 4 (optional): pulls the last `hours` of measurements for every
    pm25/pm10 sensor found across the given locations.
    """
    date_to = datetime.now(timezone.utc)
    date_from = date_to - timedelta(hours=hours)
    date_from_s = date_from.strftime("%Y-%m-%dT%H:%M:%SZ")
    date_to_s = date_to.strftime("%Y-%m-%dT%H:%M:%SZ")

    history_rows = []
    for loc in locations:
        location_id = loc.get("id")
        try:
            sensors = client.get_location_sensors(location_id)
        except requests.HTTPError:
            continue
        for sensor in sensors:
            param = (sensor.get("parameter") or {})
            if param.get("name") not in RELEVANT_PARAMETERS:
                continue
            sensor_id = sensor.get("id")
            try:
                measurements = client.get_sensor_measurements(sensor_id, date_from_s, date_to_s)
            except requests.HTTPError as e:
                logger.warning("History fetch failed for sensor %s: %s", sensor_id, e)
                continue
            for m in measurements:
                history_rows.append({
                    "location_id": location_id,
                    "sensor_id": sensor_id,
                    "pollutant_type": param.get("name"),
                    "value": m.get("value"),
                    "recorded_at": (m.get("period") or {}).get("datetimeFrom", {}).get("utc"),
                })
    logger.info("Pulled %d historical measurement rows", len(history_rows))
    return history_rows


def run(use_snowflake: bool, with_history: bool) -> None:
    client = OpenAQClient()
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    locations = client.get_pakistan_locations()
    with open(DATA_DIR / "openaq_locations_raw.json", "w") as f:
        json.dump(locations, f, indent=2)

    if not locations:
        logger.warning(
            "No OpenAQ locations returned for Pakistan. The spec notes coverage is "
            "sparse (mainly Karachi/Lahore) — proceeding with an empty result is expected "
            "in some periods; the ETL step will simply have no OpenAQ rows to join."
        )

    rows = build_raw_rows(client, locations)
    df = pd.DataFrame(rows)
    csv_path = DATA_DIR / "openaq_raw.csv"
    df.to_csv(csv_path, index=False)
    logger.info("Wrote %d OpenAQ reference rows to %s", len(df), csv_path)

    if with_history:
        history_rows = fetch_history(client, locations)
        pd.DataFrame(history_rows).to_csv(DATA_DIR / "openaq_history.csv", index=False)

    if use_snowflake and not df.empty:
        with get_connection() as conn:
            insert_dataframe(conn, df, table="OPENAQ_RAW", schema="RAW")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch Pakistan reference AQI data from OpenAQ V3")
    parser.add_argument("--history", action="store_true", help="Also pull last 24h of historical measurements")
    parser.add_argument("--no-snowflake", action="store_true", help="Only write CSV/JSON, skip Snowflake insert")
    args = parser.parse_args()

    run(use_snowflake=not args.no_snowflake, with_history=args.history)
