"""
config.py
---------
Central configuration for the Smart City AQI project.

All secrets are loaded from environment variables (via a local .env file).
NEVER hardcode credentials in source files — see .env.example for the
expected variable names.
"""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

# Loads variables from a .env file in the project root (if present) into
# the process environment. In production/CI, real env vars take precedence.
load_dotenv()


# --------------------------------------------------------------------------
# OpenAQ API configuration
# --------------------------------------------------------------------------
OPENAQ_BASE_URL = "https://api.openaq.org/v3"
OPENAQ_API_KEY = os.environ.get("OPENAQ_API_KEY")

# Free tier limits: 60 requests/min, 2000/hour. We sleep between calls to
# stay comfortably under this.
OPENAQ_REQUEST_DELAY_SECONDS = 1.0


# --------------------------------------------------------------------------
# Snowflake configuration
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class SnowflakeConfig:
    account: str
    user: str
    password: str
    role: str
    warehouse: str
    database: str = "SMART_CITY_AQI"


def get_snowflake_config() -> SnowflakeConfig:
    """Builds a SnowflakeConfig from environment variables, failing loudly
    if anything required is missing (better than a cryptic connector error).
    """
    required = [
        "SNOWFLAKE_ACCOUNT",
        "SNOWFLAKE_USER",
        "SNOWFLAKE_PASSWORD",
        "SNOWFLAKE_ROLE",
        "SNOWFLAKE_WAREHOUSE",
    ]
    missing = [var for var in required if not os.environ.get(var)]
    if missing:
        raise EnvironmentError(
            f"Missing required Snowflake env vars: {', '.join(missing)}. "
            f"Copy .env.example to .env and fill them in."
        )

    return SnowflakeConfig(
        account=os.environ["SNOWFLAKE_ACCOUNT"],
        user=os.environ["SNOWFLAKE_USER"],
        password=os.environ["SNOWFLAKE_PASSWORD"],
        role=os.environ["SNOWFLAKE_ROLE"],
        warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
        database=os.environ.get("SNOWFLAKE_DATABASE", "SMART_CITY_AQI"),
    )


# --------------------------------------------------------------------------
# Sensor network (Stage 1A spec)
# --------------------------------------------------------------------------
SENSOR_NETWORK = [
    {"sensor_id": "PKS_KHI_IND_01", "city": "Karachi",   "zone_type": "industrial",  "base_pollution": "High"},
    {"sensor_id": "PKS_KHI_TRF_02", "city": "Karachi",   "zone_type": "traffic",     "base_pollution": "Medium-High"},
    {"sensor_id": "PKS_LHR_RES_01", "city": "Lahore",    "zone_type": "residential", "base_pollution": "Medium"},
    {"sensor_id": "PKS_LHR_IND_02", "city": "Lahore",    "zone_type": "industrial",  "base_pollution": "High"},
    {"sensor_id": "PKS_ISB_PRK_01", "city": "Islamabad", "zone_type": "park",        "base_pollution": "Low"},
    {"sensor_id": "PKS_ISB_TRF_02", "city": "Islamabad", "zone_type": "traffic",     "base_pollution": "Medium-High"},
    {"sensor_id": "PKS_PEW_IND_01", "city": "Peshawar",  "zone_type": "industrial",  "base_pollution": "High"},
    {"sensor_id": "PKS_PEW_RES_02", "city": "Peshawar",  "zone_type": "residential", "base_pollution": "Medium"},
    {"sensor_id": "PKS_MUL_TRF_01", "city": "Multan",    "zone_type": "traffic",     "base_pollution": "Medium-High"},
    {"sensor_id": "PKS_MUL_PRK_02", "city": "Multan",    "zone_type": "park",        "base_pollution": "Low"},
]

# Zone-based base ranges (Stage 1A spec): pm25/co2/temp base ranges per zone
ZONE_BASE_RANGES = {
    "industrial":  {"pm25": (80, 120), "co2": (600, 900), "temp": (30, 42)},
    "traffic":     {"pm25": (55, 80),  "co2": (500, 700), "temp": (28, 40)},
    "residential": {"pm25": (25, 50),  "co2": (420, 500), "temp": (25, 38)},
    "park":        {"pm25": (8, 20),   "co2": (400, 430), "temp": (22, 35)},
}

# EPA AQI breakpoints for PM2.5: (C_lo, C_hi, I_lo, I_hi, severity_label)
AQI_BREAKPOINTS = [
    (0.0, 12.0, 0, 50, "GOOD"),
    (12.1, 35.4, 51, 100, "MODERATE"),
    (35.5, 55.4, 101, 150, "UNHEALTHY_FOR_SENSITIVE"),
    (55.5, 150.4, 151, 200, "UNHEALTHY"),
    (150.5, 250.4, 201, 300, "VERY_UNHEALTHY"),
    (250.5, 500.4, 301, 500, "HAZARDOUS"),
]
